import { AzureFunction, Context } from "@azure/functions";
import { clientId, clientSecret, email, envVariablesNames, password, urlAADApi } from "./vars";
import fetch from 'cross-fetch';
import { AADApiError, EnviromentVarNotFound } from "./exceptions";
import { DevopsTokenAPI } from "./DevopsTokenAPI";

const timerTrigger: AzureFunction = async function (context: Context, myTimer: any): Promise<void> {
    
    try {

        checkEnviromentVars();

        const AADToken = await getAADToken();
        
        const tokens = await DevopsTokenAPI.getAll(AADToken);

        tokens.forEach((token) => {
            token.setExpirationDate(newDateForToken(5));
        });

        for (const token of tokens) {
            context.log("Updating PAT '" + token.getName() + "'");
            const updated = await DevopsTokenAPI.update(AADToken, token);
            if (updated) 
                context.log("PAT '" + token.getName() + "' updated.")
        }

    } catch (error) {
        context.log(error)
    }
    
};

const getAADToken = async () => {
    const body = new URLSearchParams();
    body.append('client_id', clientId);
    body.append('scope', "499b84ac-1321-427f-aa17-267ca6975798/.default");
    body.append('client_secret', clientSecret);
    body.append('username', email);
    body.append('password', password);
    body.append('grant_type', 'password');

    const response = await fetch(urlAADApi, { method: "POST", body: body });
    const data = await response.json();
    
    if (data.error) 
        throw new AADApiError(data.error_description);

    return data.access_token;
};

const newDateForToken = (years :number) => {
    const date = new Date();
    date.setFullYear(date.getFullYear() + years);
    return date;
}

function checkEnviromentVars() {
    for (const varName of envVariablesNames) {
        const value = process.env[varName];
        if (value === '' || value == undefined) 
            throw new EnviromentVarNotFound('Environment variable "'+varName+'" not found.');
    }
}

export default timerTrigger;