export interface TokenHttp {
    displayName :string,
    validTo :string,
    scope :string,
    targetAccounts :Array<string>,
    validFrom :string,
    authorizationId :string,
    token :null
}

export class Token {

    private id :string;
    private name :string;
    private creationDate :Date;
    private expirationDate :Date;
    private scopes :Array<string>;
    private organizations :Array<string> ;

    constructor(id :string, name :string, creationDate :Date, expirationDate :Date, scopes :Array<string>, organizations :Array<string>) {
        this.id = id;
        this.name = name;
        this.creationDate = creationDate;
        this.expirationDate = expirationDate;
        this.scopes = scopes;
        this.organizations = organizations;
    }

    public getId() :string { return this.id; }
    public getName() :string { return this.name; }
    public getCreationDate() :Date { return this.creationDate; }
    public getExpirationDate() :Date { return this.expirationDate; }
    public getScopes() :Array<string> { return this.scopes; }
    public getOrganizations() :Array<string> { return this.organizations; }
    
    public setName(name :string) :void { this.name = name; }
    public setCreationDate(creationDate :Date) :void { this.creationDate = creationDate; }
    public setExpirationDate(expirationDate :Date) :void { this.expirationDate = expirationDate; }
    public setScopes(scopes :Array<string>) :void { this.scopes = scopes; }

    public static createFromObject(object :TokenHttp) {
        return new Token(
            object.authorizationId,
            object.displayName,
            new Date(object.validFrom),
            new Date(object.validTo),
            object.scope.split(" "),
            object.targetAccounts
        );
    }

}