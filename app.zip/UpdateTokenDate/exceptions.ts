export class EnviromentVarNotFound extends Error {
    constructor(message){
        super(message);
        this.name = "EnviromentVarNotFound";
    }
}

export class AADApiError extends Error {
    constructor(message){
        super(message);
        this.name = "AADApiError";
    }
}