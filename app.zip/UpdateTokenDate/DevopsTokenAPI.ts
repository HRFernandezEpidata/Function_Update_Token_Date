import fetch from 'cross-fetch';
import { Token } from './Token';
import { urlPATApi } from "./vars";

export class DevopsTokenAPI {

    public static async getAll(tokenADD) {
        const headers = {
            'Authorization': 'Bearer ' + tokenADD
        };

        const response = await fetch(urlPATApi, {
            method: "GET",
            headers: headers
        });

        const data = await response.json();

        const tokens :Array<Token> = [];

        data.patTokens.forEach(token => {
            tokens.push(Token.createFromObject(token));
        });

        return tokens;
    }

    public static async update (tokenAAD :string, token :Token) {
        const headers = {
            'Authorization': 'Bearer ' + tokenAAD,
            'Content-Type': 'application/json'
        };

        const body = {
            displayName: token.getName(),
            validTo: token.getExpirationDate(),
            scope: token.getScopes().join(" "),
            targetAccounts: token.getOrganizations(),
            validFrom: token.getCreationDate(),
            authorizationId: token.getId(),
            token :null
        }

        const response = await fetch(urlPATApi, {
            method: "PUT",
            headers: headers,
            body: JSON.stringify(body)
        });

        const data = await response.json();
        
        if (data.patTokenError === "none") return true;
        else return false;

    }

};