export const envVariablesNames = [
    'UTD_AzDevops.Org-Name',
    'UTD_AzAD.Tenant-Id',
    'UTD_Email.User',
    'UTD_Password.User',
    'UTD_AzAD.App-Id',
    'UTD_AzAD.App-Secret'
];

// Azure Directory
const tenant = process.env['UTD_AzAD.Tenant-Id'];
const clientId = process.env['UTD_AzAD.App-Id'];
const clientSecret = process.env['UTD_AzAD.App-Secret'];
const email = process.env['UTD_Email.User'];
const password = process.env['UTD_Password.User'];
const urlAADApi = 'https://login.microsoftonline.com/'+tenant+'/oauth2/v2.0/token';

export { clientId, clientSecret, email, password, urlAADApi };

// Azure DevOps
const org = process.env['UTD_AzDevops.Org-Name'];
const urlPATApi = 'https://vssps.dev.azure.com/'+org+'/_apis/tokens/pats?api-version=6.1-preview.1';

export { urlPATApi };